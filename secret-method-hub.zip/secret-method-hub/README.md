# Secret Method Hub

A full-stack MERN application with user authentication, admin approval system, and secret content access. Built with Node.js, Express, MongoDB, React, and Tailwind CSS.

## Features

### Backend Features
- **User Authentication**: Email and password-based registration and login
- **JWT Authentication**: Secure session management with JSON Web Tokens
- **Auto-generated Encrypted Keys**: Unique encrypted key for every new user
- **Admin Approval System**: Users require admin approval before accessing secret content
- **Password Security**: Bcrypt hashing for secure password storage
- **Admin Panel API**: Complete admin management endpoints
- **MongoDB Integration**: User data and approval status stored in MongoDB

### Frontend Features
- **Modern React UI**: Built with React and Tailwind CSS
- **Responsive Design**: Works on desktop and mobile devices
- **Authentication Flow**: Login/Signup pages with form validation
- **User Dashboard**: Different views based on approval status
  - Pending approval message
  - Rejection notification with reason
  - Secret content access for approved users
- **Admin Panel**: Complete user management interface
  - User statistics dashboard
  - Approve/reject users with reasons
  - Filter users by status
  - Bulk operations support
- **Protected Routes**: Role-based access control

## Tech Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - Database (with Mongoose ODM)
- **JWT** - Authentication tokens
- **bcryptjs** - Password hashing
- **crypto-js** - Encryption for user keys
- **CORS** - Cross-origin resource sharing

### Frontend
- **React** - Frontend framework
- **Tailwind CSS** - Styling framework
- **shadcn/ui** - UI component library
- **React Router** - Client-side routing
- **Axios** - HTTP client
- **Lucide React** - Icons

## Project Structure

```
secret-method-hub/
├── backend/
│   ├── models/
│   │   └── User.js              # User model with encryption
│   ├── routes/
│   │   ├── auth.js              # Authentication routes
│   │   ├── admin.js             # Admin management routes
│   │   └── users.js             # User routes
│   ├── middleware/
│   │   └── auth.js              # Authentication middleware
│   ├── utils/
│   │   ├── jwt.js               # JWT utilities
│   │   └── seedAdmin.js         # Admin user seeding
│   ├── .env                     # Environment variables
│   ├── package.json             # Backend dependencies
│   └── server.js                # Main server file
├── frontend/
│   └── secret-method-hub-frontend/
│       ├── src/
│       │   ├── components/
│       │   │   ├── auth/        # Authentication components
│       │   │   ├── admin/       # Admin panel components
│       │   │   └── user/        # User dashboard components
│       │   ├── context/
│       │   │   └── AuthContext.jsx  # Authentication context
│       │   ├── services/
│       │   │   └── api.js       # API service configuration
│       │   └── App.jsx          # Main app component
│       ├── package.json         # Frontend dependencies
│       └── index.html           # HTML entry point
└── README.md                    # This file
```

## Setup Instructions

### Prerequisites
- Node.js (v16 or higher)
- MongoDB Atlas account (free tier)
- Git

### Local Development Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd secret-method-hub
   ```

2. **Backend Setup**
   ```bash
   cd backend
   npm install
   ```

3. **Configure Environment Variables**
   
   Create a `.env` file in the backend directory:
   ```env
   PORT=5000
   MONGODB_URI=mongodb+srv://your-username:your-password@cluster0.mongodb.net/secret-method-hub?retryWrites=true&w=majority
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   ADMIN_EMAIL=admin@secretmethod.com
   ADMIN_PASSWORD=admin123
   ENCRYPTION_KEY=your-32-character-encryption-key-here
   ```

4. **Frontend Setup**
   ```bash
   cd ../frontend/secret-method-hub-frontend
   npm install
   ```

5. **Start the Application**
   
   **Terminal 1 - Backend:**
   ```bash
   cd backend
   npm run dev
   ```
   
   **Terminal 2 - Frontend:**
   ```bash
   cd frontend/secret-method-hub-frontend
   npm run dev
   ```

6. **Access the Application**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:5000

### MongoDB Atlas Setup

1. **Create MongoDB Atlas Account**
   - Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
   - Create a free account and cluster

2. **Configure Database Access**
   - Create a database user with read/write permissions
   - Add your IP address to the IP whitelist (or use 0.0.0.0/0 for development)

3. **Get Connection String**
   - Click "Connect" on your cluster
   - Choose "Connect your application"
   - Copy the connection string and update the `MONGODB_URI` in your `.env` file

## Replit Deployment

### Setting up on Replit

1. **Create New Repl**
   - Go to [Replit](https://replit.com)
   - Create a new Repl and choose "Import from GitHub"
   - Import your repository

2. **Configure Environment Variables**
   - In Replit, go to the "Secrets" tab (lock icon)
   - Add all environment variables from the `.env` file:
     - `MONGODB_URI`
     - `JWT_SECRET`
     - `ADMIN_EMAIL`
     - `ADMIN_PASSWORD`
     - `ENCRYPTION_KEY`

3. **Install Dependencies**
   
   **Backend:**
   ```bash
   cd backend
   npm install
   ```
   
   **Frontend:**
   ```bash
   cd frontend/secret-method-hub-frontend
   npm install
   ```

4. **Create Replit Configuration**
   
   Create a `.replit` file in the root directory:
   ```toml
   run = "cd backend && npm start"
   
   [nix]
   channel = "stable-22_11"
   
   [deployment]
   run = ["sh", "-c", "cd backend && npm start"]
   ```

5. **Update Package.json Scripts**
   
   In `backend/package.json`, ensure you have:
   ```json
   {
     "scripts": {
       "start": "node server.js",
       "dev": "nodemon server.js"
     }
   }
   ```

6. **Frontend Build for Production**
   
   In `frontend/secret-method-hub-frontend`, update the API base URL in `src/services/api.js`:
   ```javascript
   const api = axios.create({
     baseURL: process.env.NODE_ENV === 'production' 
       ? 'https://your-repl-name.your-username.repl.co/api'
       : 'http://localhost:5000/api',
     // ... rest of config
   });
   ```

7. **Build and Serve Frontend**
   ```bash
   cd frontend/secret-method-hub-frontend
   npm run build
   ```

8. **Serve Frontend from Backend**
   
   Update `backend/server.js` to serve the built frontend:
   ```javascript
   const path = require('path');
   
   // Serve static files from React build
   app.use(express.static(path.join(__dirname, '../frontend/secret-method-hub-frontend/dist')));
   
   // Handle React routing, return all requests to React app
   app.get('*', (req, res) => {
     res.sendFile(path.join(__dirname, '../frontend/secret-method-hub-frontend/dist', 'index.html'));
   });
   ```

### Running on Replit

1. **Start the Application**
   - Click the "Run" button in Replit
   - The backend will start on the default port
   - Access your app via the Replit-provided URL

2. **Access Admin Panel**
   - Default admin credentials:
     - Email: admin@secretmethod.com
     - Password: admin123
   - Change these in production!

## API Endpoints

### Authentication Routes (`/api/auth`)
- `POST /register` - Register new user
- `POST /login` - User login
- `GET /profile` - Get current user profile
- `GET /secret-key` - Get user's encrypted key (approved users only)
- `POST /verify` - Verify JWT token

### User Routes (`/api/users`)
- `GET /status` - Get user approval status
- `GET /secret-content` - Get secret content (approved users only)
- `PUT /profile` - Update user profile
- `DELETE /account` - Delete user account

### Admin Routes (`/api/admin`)
- `GET /users` - Get all users with filtering
- `GET /stats` - Get user statistics
- `POST /approve/:userId` - Approve user
- `POST /reject/:userId` - Reject user with reason
- `GET /user/:userId` - Get specific user details
- `POST /bulk-approve` - Bulk approve users

## Default Admin Account

The application automatically creates an admin account on first run:
- **Email**: admin@secretmethod.com
- **Password**: admin123

**⚠️ Important**: Change these credentials in production by updating the environment variables.

## Security Features

- **Password Hashing**: All passwords are hashed using bcrypt
- **JWT Authentication**: Secure token-based authentication
- **Encrypted User Keys**: Each user gets a unique encrypted key
- **Protected Routes**: Role-based access control
- **Input Validation**: Form validation on both frontend and backend
- **CORS Configuration**: Proper cross-origin resource sharing setup

## User Flow

1. **Registration**: User creates account with email and password
2. **Automatic Key Generation**: System generates unique encrypted key
3. **Pending Approval**: User sees "Waiting for Approval" message
4. **Admin Review**: Admin can approve or reject with reason
5. **Access Granted**: Approved users can access secret content
6. **Secret Content**: Links, videos, and downloadable resources

## Customization

### Adding Secret Content

Edit the secret content in `backend/routes/users.js` in the `/secret-content` endpoint:

```javascript
const secretContent = {
  message: "Your custom message",
  links: [
    {
      title: "Your Secret Link",
      url: "https://your-secret-url.com",
      description: "Description of your secret content"
    }
  ],
  videos: [
    {
      title: "Your Secret Video",
      embedUrl: "https://youtube.com/embed/your-video-id",
      description: "Video description"
    }
  ],
  documents: [
    {
      title: "Your Secret Document",
      downloadUrl: "https://your-document-url.com/doc.pdf",
      description: "Document description"
    }
  ]
};
```

### Styling Customization

The application uses Tailwind CSS and shadcn/ui components. You can customize:
- Colors in `frontend/secret-method-hub-frontend/src/App.css`
- Components in the respective component files
- Layout and spacing using Tailwind classes

## Troubleshooting

### Common Issues

1. **MongoDB Connection Error**
   - Verify your MongoDB URI is correct
   - Check if your IP is whitelisted in MongoDB Atlas
   - Ensure database user has proper permissions

2. **CORS Errors**
   - Verify the frontend URL is allowed in CORS configuration
   - Check if the API base URL is correct in the frontend

3. **JWT Token Issues**
   - Ensure JWT_SECRET is set in environment variables
   - Check if token is being sent in Authorization header

4. **Admin Account Not Created**
   - Check MongoDB connection
   - Verify admin credentials in environment variables
   - Check server logs for errors

### Development Tips

- Use `npm run dev` for development with auto-restart
- Check browser console for frontend errors
- Monitor server logs for backend issues
- Use MongoDB Compass to inspect database data

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Support

For support and questions:
- Check the troubleshooting section
- Review the API documentation
- Create an issue in the repository

---

**Note**: This application is designed for educational and demonstration purposes. Ensure proper security measures are implemented before using in production.

