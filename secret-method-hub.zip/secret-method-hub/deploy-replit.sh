#!/bin/bash

echo "🚀 Secret Method Hub - Replit Deployment Setup"
echo "=============================================="

# Check if we're in the right directory
if [ ! -f "package.json" ] && [ ! -d "backend" ]; then
    echo "❌ Error: Please run this script from the project root directory"
    exit 1
fi

echo "📦 Installing backend dependencies..."
cd backend
npm install
if [ $? -ne 0 ]; then
    echo "❌ Backend dependency installation failed"
    exit 1
fi
echo "✅ Backend dependencies installed"

echo "📦 Installing frontend dependencies..."
cd ../frontend/secret-method-hub-frontend
npm install
if [ $? -ne 0 ]; then
    echo "❌ Frontend dependency installation failed"
    exit 1
fi
echo "✅ Frontend dependencies installed"

echo "🏗️  Building frontend for production..."
npm run build
if [ $? -ne 0 ]; then
    echo "❌ Frontend build failed"
    exit 1
fi
echo "✅ Frontend built successfully"

echo "📁 Setting up static file serving..."
cd ../../backend

# Create a backup of the original server.js
cp server.js server.js.backup

# Add static file serving to server.js
cat >> server.js << 'EOF'

// Serve static files from React build (for production)
if (process.env.NODE_ENV === 'production') {
  const path = require('path');
  
  // Serve static files from React build
  app.use(express.static(path.join(__dirname, '../frontend/secret-method-hub-frontend/dist')));
  
  // Handle React routing, return all requests to React app
  app.get('*', (req, res) => {
    if (req.path.startsWith('/api')) {
      return next(); // Let API routes handle API requests
    }
    res.sendFile(path.join(__dirname, '../frontend/secret-method-hub-frontend/dist', 'index.html'));
  });
}
EOF

echo "✅ Static file serving configured"

echo ""
echo "🎉 Deployment setup complete!"
echo ""
echo "📋 Next steps for Replit:"
echo "1. Set up environment variables in Replit Secrets:"
echo "   - MONGODB_URI (your MongoDB Atlas connection string)"
echo "   - JWT_SECRET (a secure random string)"
echo "   - ADMIN_EMAIL (admin email address)"
echo "   - ADMIN_PASSWORD (admin password)"
echo "   - ENCRYPTION_KEY (32-character encryption key)"
echo ""
echo "2. Click the 'Run' button in Replit"
echo ""
echo "3. Your app will be available at the Replit-provided URL"
echo ""
echo "🔐 Default admin credentials:"
echo "   Email: admin@secretmethod.com"
echo "   Password: admin123"
echo "   (Change these in production!)"
echo ""
echo "📚 For detailed instructions, see README.md"

