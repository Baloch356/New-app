const User = require('../models/User');

const seedAdmin = async () => {
  try {
    // Check if admin already exists
    const existingAdmin = await User.findOne({ 
      email: process.env.ADMIN_EMAIL || 'admin@secretmethod.com' 
    });

    if (existingAdmin) {
      console.log('Admin user already exists');
      return existingAdmin;
    }

    // Create admin user
    const adminUser = new User({
      email: process.env.ADMIN_EMAIL || 'admin@secretmethod.com',
      password: process.env.ADMIN_PASSWORD || 'admin123',
      firstName: 'Admin',
      lastName: 'User',
      isAdmin: true,
      isApproved: true,
      approvedAt: new Date()
    });

    await adminUser.save();
    console.log('Admin user created successfully');
    console.log(`Admin Email: ${adminUser.email}`);
    console.log(`Admin Password: ${process.env.ADMIN_PASSWORD || 'admin123'}`);
    
    return adminUser;
  } catch (error) {
    console.error('Error creating admin user:', error);
    throw error;
  }
};

module.exports = seedAdmin;

