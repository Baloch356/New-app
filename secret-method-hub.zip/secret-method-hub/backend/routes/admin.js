const express = require('express');
const User = require('../models/User');
const { requireAdminApproval } = require('../middleware/auth');

const router = express.Router();

// Get all users (admin only)
router.get('/users', requireAdminApproval, async (req, res) => {
  try {
    const { page = 1, limit = 10, status = 'all' } = req.query;
    
    let filter = { isAdmin: false }; // Exclude admin users from the list
    
    // Filter by approval status
    if (status === 'pending') {
      filter.isApproved = false;
      filter.rejectedAt = null;
    } else if (status === 'approved') {
      filter.isApproved = true;
    } else if (status === 'rejected') {
      filter.rejectedAt = { $ne: null };
    }

    const users = await User.find(filter)
      .select('-password -encryptedKey')
      .populate('approvedBy', 'firstName lastName email')
      .populate('rejectedBy', 'firstName lastName email')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await User.countDocuments(filter);

    res.json({
      users,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalUsers: total,
        hasNext: page * limit < total,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ message: 'Failed to retrieve users' });
  }
});

// Get user statistics (admin only)
router.get('/stats', requireAdminApproval, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ isAdmin: false });
    const approvedUsers = await User.countDocuments({ isApproved: true, isAdmin: false });
    const pendingUsers = await User.countDocuments({ 
      isApproved: false, 
      rejectedAt: null, 
      isAdmin: false 
    });
    const rejectedUsers = await User.countDocuments({ 
      rejectedAt: { $ne: null }, 
      isAdmin: false 
    });

    // Get recent registrations (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recentRegistrations = await User.countDocuments({
      createdAt: { $gte: sevenDaysAgo },
      isAdmin: false
    });

    res.json({
      totalUsers,
      approvedUsers,
      pendingUsers,
      rejectedUsers,
      recentRegistrations,
      approvalRate: totalUsers > 0 ? ((approvedUsers / totalUsers) * 100).toFixed(1) : 0
    });
  } catch (error) {
    console.error('Get stats error:', error);
    res.status(500).json({ message: 'Failed to retrieve statistics' });
  }
});

// Approve user (admin only)
router.post('/approve/:userId', requireAdminApproval, async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.isAdmin) {
      return res.status(400).json({ message: 'Cannot modify admin user' });
    }

    if (user.isApproved) {
      return res.status(400).json({ message: 'User is already approved' });
    }

    await user.approve(req.user._id);

    res.json({
      message: 'User approved successfully',
      user: {
        id: user._id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        isApproved: user.isApproved,
        approvedAt: user.approvedAt
      }
    });
  } catch (error) {
    console.error('Approve user error:', error);
    res.status(500).json({ message: 'Failed to approve user' });
  }
});

// Reject user (admin only)
router.post('/reject/:userId', requireAdminApproval, async (req, res) => {
  try {
    const { userId } = req.params;
    const { reason } = req.body;
    
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (user.isAdmin) {
      return res.status(400).json({ message: 'Cannot modify admin user' });
    }

    await user.reject(req.user._id, reason);

    res.json({
      message: 'User rejected successfully',
      user: {
        id: user._id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        isApproved: user.isApproved,
        rejectedAt: user.rejectedAt,
        rejectionReason: user.rejectionReason
      }
    });
  } catch (error) {
    console.error('Reject user error:', error);
    res.status(500).json({ message: 'Failed to reject user' });
  }
});

// Get specific user details (admin only)
router.get('/user/:userId', requireAdminApproval, async (req, res) => {
  try {
    const { userId } = req.params;
    
    const user = await User.findById(userId)
      .select('-password -encryptedKey')
      .populate('approvedBy', 'firstName lastName email')
      .populate('rejectedBy', 'firstName lastName email');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Get user details error:', error);
    res.status(500).json({ message: 'Failed to retrieve user details' });
  }
});

// Bulk approve users (admin only)
router.post('/bulk-approve', requireAdminApproval, async (req, res) => {
  try {
    const { userIds } = req.body;
    
    if (!Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ message: 'User IDs array is required' });
    }

    const users = await User.find({ 
      _id: { $in: userIds }, 
      isAdmin: false,
      isApproved: false 
    });

    const approvedUsers = [];
    for (const user of users) {
      await user.approve(req.user._id);
      approvedUsers.push({
        id: user._id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName
      });
    }

    res.json({
      message: `${approvedUsers.length} users approved successfully`,
      approvedUsers
    });
  } catch (error) {
    console.error('Bulk approve error:', error);
    res.status(500).json({ message: 'Failed to approve users' });
  }
});

module.exports = router;

