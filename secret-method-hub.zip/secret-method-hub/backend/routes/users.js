const express = require('express');
const User = require('../models/User');
const { authenticateToken, requireApproval } = require('../middleware/auth');

const router = express.Router();

// Get current user's approval status
router.get('/status', authenticateToken, (req, res) => {
  res.json({
    user: {
      id: req.user._id,
      email: req.user.email,
      firstName: req.user.firstName,
      lastName: req.user.lastName,
      isApproved: req.user.isApproved,
      isAdmin: req.user.isAdmin,
      approvedAt: req.user.approvedAt,
      rejectedAt: req.user.rejectedAt,
      rejectionReason: req.user.rejectionReason,
      createdAt: req.user.createdAt
    }
  });
});

// Get secret content (only for approved users)
router.get('/secret-content', [authenticateToken, requireApproval], (req, res) => {
  // This is where you would return the secret content
  // For now, returning sample content
  const secretContent = {
    message: "Congratulations! You have been approved and can now access the secret content.",
    links: [
      {
        title: "Secret Method #1: Advanced Techniques",
        url: "https://example.com/secret-method-1",
        description: "Learn the first secret method that will transform your approach."
      },
      {
        title: "Secret Method #2: Hidden Strategies",
        url: "https://example.com/secret-method-2", 
        description: "Discover the hidden strategies used by experts."
      },
      {
        title: "Exclusive Video Content",
        url: "https://example.com/exclusive-videos",
        description: "Access to exclusive video tutorials and masterclasses."
      }
    ],
    videos: [
      {
        title: "Master Class: Secret Techniques Revealed",
        embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        description: "A comprehensive masterclass revealing all secret techniques."
      },
      {
        title: "Advanced Training Session",
        embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        description: "Advanced training for implementing the secret methods."
      }
    ],
    documents: [
      {
        title: "Secret Method Handbook",
        downloadUrl: "https://example.com/handbook.pdf",
        description: "Complete handbook with all secret methods documented."
      },
      {
        title: "Implementation Guide",
        downloadUrl: "https://example.com/guide.pdf",
        description: "Step-by-step implementation guide."
      }
    ],
    lastUpdated: new Date().toISOString()
  };

  res.json({
    message: "Secret content retrieved successfully",
    content: secretContent,
    userKey: req.user.getDecryptedKey()
  });
});

// Update user profile
router.put('/profile', authenticateToken, async (req, res) => {
  try {
    const { firstName, lastName } = req.body;
    
    // Validate input
    if (!firstName || !lastName) {
      return res.status(400).json({ 
        message: 'First name and last name are required' 
      });
    }

    // Update user
    req.user.firstName = firstName;
    req.user.lastName = lastName;
    await req.user.save();

    res.json({
      message: 'Profile updated successfully',
      user: {
        id: req.user._id,
        email: req.user.email,
        firstName: req.user.firstName,
        lastName: req.user.lastName,
        isApproved: req.user.isApproved,
        isAdmin: req.user.isAdmin
      }
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Failed to update profile' });
  }
});

// Delete user account (self-deletion)
router.delete('/account', authenticateToken, async (req, res) => {
  try {
    if (req.user.isAdmin) {
      return res.status(400).json({ message: 'Admin accounts cannot be deleted' });
    }

    await User.findByIdAndDelete(req.user._id);

    res.json({
      message: 'Account deleted successfully'
    });
  } catch (error) {
    console.error('Delete account error:', error);
    res.status(500).json({ message: 'Failed to delete account' });
  }
});

module.exports = router;

