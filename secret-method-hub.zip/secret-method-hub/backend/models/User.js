const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const crypto = require('crypto-js');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  firstName: {
    type: String,
    required: true,
    trim: true
  },
  lastName: {
    type: String,
    required: true,
    trim: true
  },
  encryptedKey: {
    type: String,
    required: true,
    unique: true
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  isAdmin: {
    type: Boolean,
    default: false
  },
  approvedAt: {
    type: Date,
    default: null
  },
  approvedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  rejectedAt: {
    type: Date,
    default: null
  },
  rejectedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  rejectionReason: {
    type: String,
    default: null
  }
}, {
  timestamps: true
});

// Generate unique encrypted key before saving
userSchema.pre('save', async function(next) {
  if (!this.isNew) return next();
  
  try {
    // Generate a unique key for the user
    const uniqueString = `${this.email}-${Date.now()}-${Math.random()}`;
    const encryptionKey = process.env.ENCRYPTION_KEY || 'default-key-change-this-in-production';
    
    // Encrypt the unique string
    this.encryptedKey = crypto.AES.encrypt(uniqueString, encryptionKey).toString();
    
    next();
  } catch (error) {
    next(error);
  }
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Get decrypted key method
userSchema.methods.getDecryptedKey = function() {
  try {
    const encryptionKey = process.env.ENCRYPTION_KEY || 'default-key-change-this-in-production';
    const bytes = crypto.AES.decrypt(this.encryptedKey, encryptionKey);
    return bytes.toString(crypto.enc.Utf8);
  } catch (error) {
    return null;
  }
};

// Approve user method
userSchema.methods.approve = function(adminId) {
  this.isApproved = true;
  this.approvedAt = new Date();
  this.approvedBy = adminId;
  this.rejectedAt = null;
  this.rejectedBy = null;
  this.rejectionReason = null;
  return this.save();
};

// Reject user method
userSchema.methods.reject = function(adminId, reason = null) {
  this.isApproved = false;
  this.rejectedAt = new Date();
  this.rejectedBy = adminId;
  this.rejectionReason = reason;
  this.approvedAt = null;
  this.approvedBy = null;
  return this.save();
};

// Remove sensitive data when converting to JSON
userSchema.methods.toJSON = function() {
  const user = this.toObject();
  delete user.password;
  delete user.encryptedKey;
  return user;
};

module.exports = mongoose.model('User', userSchema);

