from flask_sqlalchemy import SQLAlchemy
from flask_pymongo import PyMongo
from datetime import datetime
import bcrypt
from cryptography.fernet import Fernet
import base64
import os

# Keep SQLAlchemy for compatibility but we'll use MongoDB
db = SQLAlchemy()

class UserModel:
    def __init__(self, mongo):
        self.mongo = mongo
        self.collection = mongo.db.users
    
    def create_user(self, email, password, first_name, last_name):
        """Create a new user with encrypted key"""
        # Check if user already exists
        if self.collection.find_one({"email": email}):
            return None
        
        # Hash password
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        
        # Generate encrypted key
        encrypted_key = self._generate_encrypted_key(email)
        
        user_data = {
            "email": email,
            "password": password_hash,
            "firstName": first_name,
            "lastName": last_name,
            "encryptedKey": encrypted_key,
            "isApproved": False,
            "isAdmin": False,
            "approvedAt": None,
            "approvedBy": None,
            "rejectedAt": None,
            "rejectedBy": None,
            "rejectionReason": None,
            "createdAt": datetime.utcnow(),
            "updatedAt": datetime.utcnow()
        }
        
        result = self.collection.insert_one(user_data)
        user_data['_id'] = result.inserted_id
        return user_data
    
    def find_by_email(self, email):
        """Find user by email"""
        return self.collection.find_one({"email": email})
    
    def find_by_id(self, user_id):
        """Find user by ID"""
        from bson import ObjectId
        return self.collection.find_one({"_id": ObjectId(user_id)})
    
    def verify_password(self, user, password):
        """Verify user password"""
        return bcrypt.checkpw(password.encode('utf-8'), user['password'])
    
    def approve_user(self, user_id, admin_id):
        """Approve a user"""
        from bson import ObjectId
        result = self.collection.update_one(
            {"_id": ObjectId(user_id)},
            {
                "$set": {
                    "isApproved": True,
                    "approvedAt": datetime.utcnow(),
                    "approvedBy": ObjectId(admin_id),
                    "rejectedAt": None,
                    "rejectedBy": None,
                    "rejectionReason": None,
                    "updatedAt": datetime.utcnow()
                }
            }
        )
        return result.modified_count > 0
    
    def reject_user(self, user_id, admin_id, reason=None):
        """Reject a user"""
        from bson import ObjectId
        result = self.collection.update_one(
            {"_id": ObjectId(user_id)},
            {
                "$set": {
                    "isApproved": False,
                    "rejectedAt": datetime.utcnow(),
                    "rejectedBy": ObjectId(admin_id),
                    "rejectionReason": reason,
                    "approvedAt": None,
                    "approvedBy": None,
                    "updatedAt": datetime.utcnow()
                }
            }
        )
        return result.modified_count > 0
    
    def get_users_by_status(self, status="all", page=1, limit=10):
        """Get users filtered by status"""
        filter_query = {"isAdmin": False}
        
        if status == "pending":
            filter_query.update({"isApproved": False, "rejectedAt": None})
        elif status == "approved":
            filter_query.update({"isApproved": True})
        elif status == "rejected":
            filter_query.update({"rejectedAt": {"$ne": None}})
        
        skip = (page - 1) * limit
        users = list(self.collection.find(filter_query).sort("createdAt", -1).skip(skip).limit(limit))
        total = self.collection.count_documents(filter_query)
        
        return users, total
    
    def get_user_stats(self):
        """Get user statistics"""
        total_users = self.collection.count_documents({"isAdmin": False})
        approved_users = self.collection.count_documents({"isApproved": True, "isAdmin": False})
        pending_users = self.collection.count_documents({
            "isApproved": False, 
            "rejectedAt": None, 
            "isAdmin": False
        })
        rejected_users = self.collection.count_documents({
            "rejectedAt": {"$ne": None}, 
            "isAdmin": False
        })
        
        # Recent registrations (last 7 days)
        from datetime import timedelta
        seven_days_ago = datetime.utcnow() - timedelta(days=7)
        recent_registrations = self.collection.count_documents({
            "createdAt": {"$gte": seven_days_ago},
            "isAdmin": False
        })
        
        return {
            "totalUsers": total_users,
            "approvedUsers": approved_users,
            "pendingUsers": pending_users,
            "rejectedUsers": rejected_users,
            "recentRegistrations": recent_registrations,
            "approvalRate": round((approved_users / total_users * 100), 1) if total_users > 0 else 0
        }
    
    def create_admin_user(self, email, password, first_name="Admin", last_name="User"):
        """Create admin user"""
        # Check if admin already exists
        if self.collection.find_one({"email": email}):
            return self.collection.find_one({"email": email})
        
        # Hash password
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        
        # Generate encrypted key
        encrypted_key = self._generate_encrypted_key(email)
        
        admin_data = {
            "email": email,
            "password": password_hash,
            "firstName": first_name,
            "lastName": last_name,
            "encryptedKey": encrypted_key,
            "isApproved": True,
            "isAdmin": True,
            "approvedAt": datetime.utcnow(),
            "approvedBy": None,
            "rejectedAt": None,
            "rejectedBy": None,
            "rejectionReason": None,
            "createdAt": datetime.utcnow(),
            "updatedAt": datetime.utcnow()
        }
        
        result = self.collection.insert_one(admin_data)
        admin_data['_id'] = result.inserted_id
        return admin_data
    
    def _generate_encrypted_key(self, email):
        """Generate encrypted key for user"""
        # Create a unique string
        unique_string = f"{email}-{datetime.utcnow().timestamp()}"
        
        # Get encryption key from environment or use default
        encryption_key = os.getenv('ENCRYPTION_KEY', 'default-key-change-this-in-production-32chars')
        
        # Ensure key is 32 bytes for Fernet
        key = base64.urlsafe_b64encode(encryption_key.encode()[:32].ljust(32, b'0'))
        fernet = Fernet(key)
        
        # Encrypt the unique string
        encrypted = fernet.encrypt(unique_string.encode())
        return encrypted.decode()
    
    def decrypt_user_key(self, encrypted_key):
        """Decrypt user key"""
        try:
            encryption_key = os.getenv('ENCRYPTION_KEY', 'default-key-change-this-in-production-32chars')
            key = base64.urlsafe_b64encode(encryption_key.encode()[:32].ljust(32, b'0'))
            fernet = Fernet(key)
            
            decrypted = fernet.decrypt(encrypted_key.encode())
            return decrypted.decode()
        except Exception:
            return None
    
    def update_user_profile(self, user_id, first_name, last_name):
        """Update user profile"""
        from bson import ObjectId
        result = self.collection.update_one(
            {"_id": ObjectId(user_id)},
            {
                "$set": {
                    "firstName": first_name,
                    "lastName": last_name,
                    "updatedAt": datetime.utcnow()
                }
            }
        )
        return result.modified_count > 0
    
    def delete_user(self, user_id):
        """Delete user account"""
        from bson import ObjectId
        result = self.collection.delete_one({"_id": ObjectId(user_id), "isAdmin": False})
        return result.deleted_count > 0

