import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from flask_pymongo import PyMongo
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from dotenv import load_dotenv
from src.models.user import db, UserModel
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.admin import admin_bp

# Load environment variables
load_dotenv()

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Configuration
app.config['SECRET_KEY'] = os.getenv('JWT_SECRET', 'your-super-secret-jwt-key-change-this-in-production')
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET', 'your-super-secret-jwt-key-change-this-in-production')
app.config['MONGO_URI'] = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/secret-method-hub')

# Initialize extensions
mongo = PyMongo(app)
jwt = JWTManager(app)
CORS(app, origins="*", supports_credentials=True)

# Store mongo instance in app for access in routes
app.mongo = mongo

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(admin_bp, url_prefix='/api/admin')
app.register_blueprint(user_bp, url_prefix='/api/users')

# Keep SQLAlchemy setup for compatibility
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
with app.app_context():
    db.create_all()

# API root endpoint
@app.route('/api')
def api_root():
    return jsonify({
        'message': 'Secret Method Hub API is running!',
        'version': '1.0.0',
        'endpoints': {
            'auth': '/api/auth',
            'admin': '/api/admin',
            'users': '/api/users'
        }
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'message': 'Route not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'message': 'Internal server error'}), 500

@app.errorhandler(401)
def unauthorized(error):
    return jsonify({'message': 'Unauthorized access'}), 401

@app.errorhandler(403)
def forbidden(error):
    return jsonify({'message': 'Forbidden access'}), 403

# JWT error handlers
@jwt.expired_token_loader
def expired_token_callback(jwt_header, jwt_payload):
    return jsonify({'message': 'Token has expired'}), 401

@jwt.invalid_token_loader
def invalid_token_callback(error):
    return jsonify({'message': 'Invalid token'}), 401

@jwt.unauthorized_loader
def missing_token_callback(error):
    return jsonify({'message': 'Access token required'}), 401

# Serve static files and handle React routing
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

# Initialize admin user on startup
def create_admin_user():
    """Create admin user if it doesn't exist"""
    try:
        user_model = UserModel(mongo)
        admin_email = os.getenv('ADMIN_EMAIL', 'admin@secretmethod.com')
        admin_password = os.getenv('ADMIN_PASSWORD', 'admin123')
        
        admin_user = user_model.create_admin_user(admin_email, admin_password)
        if admin_user:
            print(f"Admin user created/verified: {admin_email}")
        else:
            print("Admin user already exists")
    except Exception as e:
        print(f"Error creating admin user: {e}")

if __name__ == '__main__':
    with app.app_context():
        create_admin_user()
    app.run(host='0.0.0.0', port=5000, debug=True)

