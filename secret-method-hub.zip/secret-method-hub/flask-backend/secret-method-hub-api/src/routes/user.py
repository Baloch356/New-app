from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import UserModel
from datetime import datetime

user_bp = Blueprint('user', __name__)

def get_user_model():
    """Get user model instance"""
    return UserModel(current_app.mongo)

@user_bp.route('/status', methods=['GET'])
@jwt_required()
def get_user_status():
    try:
        user_id = get_jwt_identity()
        user_model = get_user_model()
        
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        return jsonify({
            'user': {
                'id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'isApproved': user['isApproved'],
                'isAdmin': user['isAdmin'],
                'approvedAt': user['approvedAt'].isoformat() if user['approvedAt'] else None,
                'rejectedAt': user['rejectedAt'].isoformat() if user['rejectedAt'] else None,
                'rejectionReason': user.get('rejectionReason'),
                'createdAt': user['createdAt'].isoformat()
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to get user status', 'error': str(e)}), 500

@user_bp.route('/secret-content', methods=['GET'])
@jwt_required()
def get_secret_content():
    try:
        user_id = get_jwt_identity()
        user_model = get_user_model()
        
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if not user['isApproved']:
            return jsonify({
                'message': 'Account pending approval',
                'isApproved': False
            }), 403
        
        # Secret content - customize this as needed
        secret_content = {
            "message": "Congratulations! You have been approved and can now access the secret content.",
            "links": [
                {
                    "title": "Secret Method #1: Advanced Techniques",
                    "url": "https://example.com/secret-method-1",
                    "description": "Learn the first secret method that will transform your approach."
                },
                {
                    "title": "Secret Method #2: Hidden Strategies",
                    "url": "https://example.com/secret-method-2", 
                    "description": "Discover the hidden strategies used by experts."
                },
                {
                    "title": "Exclusive Video Content",
                    "url": "https://example.com/exclusive-videos",
                    "description": "Access to exclusive video tutorials and masterclasses."
                }
            ],
            "videos": [
                {
                    "title": "Master Class: Secret Techniques Revealed",
                    "embedUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ",
                    "description": "A comprehensive masterclass revealing all secret techniques."
                },
                {
                    "title": "Advanced Training Session",
                    "embedUrl": "https://www.youtube.com/embed/dQw4w9WgXcQ",
                    "description": "Advanced training for implementing the secret methods."
                }
            ],
            "documents": [
                {
                    "title": "Secret Method Handbook",
                    "downloadUrl": "https://example.com/handbook.pdf",
                    "description": "Complete handbook with all secret methods documented."
                },
                {
                    "title": "Implementation Guide",
                    "downloadUrl": "https://example.com/guide.pdf",
                    "description": "Step-by-step implementation guide."
                }
            ],
            "lastUpdated": datetime.utcnow().isoformat()
        }
        
        # Get user's decrypted key
        user_key = user_model.decrypt_user_key(user['encryptedKey'])
        
        return jsonify({
            'message': 'Secret content retrieved successfully',
            'content': secret_content,
            'userKey': user_key
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve secret content', 'error': str(e)}), 500

@user_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        first_name = data.get('firstName', '').strip()
        last_name = data.get('lastName', '').strip()
        
        if not first_name or not last_name:
            return jsonify({'message': 'First name and last name are required'}), 400
        
        user_model = get_user_model()
        
        # Update user profile
        success = user_model.update_user_profile(user_id, first_name, last_name)
        if not success:
            return jsonify({'message': 'Failed to update profile'}), 500
        
        # Get updated user
        user = user_model.find_by_id(user_id)
        
        return jsonify({
            'message': 'Profile updated successfully',
            'user': {
                'id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'isApproved': user['isApproved'],
                'isAdmin': user['isAdmin']
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to update profile', 'error': str(e)}), 500

@user_bp.route('/account', methods=['DELETE'])
@jwt_required()
def delete_account():
    try:
        user_id = get_jwt_identity()
        user_model = get_user_model()
        
        # Check if user is admin
        user = user_model.find_by_id(user_id)
        if user and user['isAdmin']:
            return jsonify({'message': 'Admin accounts cannot be deleted'}), 400
        
        # Delete user account
        success = user_model.delete_user(user_id)
        if not success:
            return jsonify({'message': 'Failed to delete account'}), 500
        
        return jsonify({'message': 'Account deleted successfully'})
        
    except Exception as e:
        return jsonify({'message': 'Failed to delete account', 'error': str(e)}), 500

