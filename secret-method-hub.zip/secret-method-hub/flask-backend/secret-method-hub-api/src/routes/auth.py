from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from src.models.user import UserModel
import re

auth_bp = Blueprint('auth', __name__)

def get_user_model():
    """Get user model instance"""
    return UserModel(current_app.mongo)

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['email', 'password', 'firstName', 'lastName']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'message': 'All fields are required',
                    'required': required_fields
                }), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        first_name = data['firstName'].strip()
        last_name = data['lastName'].strip()
        
        # Validate email format
        if not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
            return jsonify({'message': 'Invalid email format'}), 400
        
        # Validate password length
        if len(password) < 6:
            return jsonify({'message': 'Password must be at least 6 characters'}), 400
        
        user_model = get_user_model()
        
        # Create user
        user = user_model.create_user(email, password, first_name, last_name)
        if not user:
            return jsonify({'message': 'User already exists with this email'}), 409
        
        # Generate JWT token
        access_token = create_access_token(
            identity=str(user['_id']),
            additional_claims={
                'email': user['email'],
                'isAdmin': user['isAdmin']
            }
        )
        
        return jsonify({
            'message': 'User registered successfully',
            'token': access_token,
            'user': {
                'id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'isApproved': user['isApproved'],
                'isAdmin': user['isAdmin']
            }
        }), 201
        
    except Exception as e:
        return jsonify({'message': 'Registration failed', 'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('email') or not data.get('password'):
            return jsonify({'message': 'Email and password are required'}), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        
        user_model = get_user_model()
        
        # Find user
        user = user_model.find_by_email(email)
        if not user:
            return jsonify({'message': 'Invalid email or password'}), 401
        
        # Verify password
        if not user_model.verify_password(user, password):
            return jsonify({'message': 'Invalid email or password'}), 401
        
        # Generate JWT token
        access_token = create_access_token(
            identity=str(user['_id']),
            additional_claims={
                'email': user['email'],
                'isAdmin': user['isAdmin']
            }
        )
        
        return jsonify({
            'message': 'Login successful',
            'token': access_token,
            'user': {
                'id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'isApproved': user['isApproved'],
                'isAdmin': user['isAdmin']
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Login failed', 'error': str(e)}), 500

@auth_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    try:
        user_id = get_jwt_identity()
        user_model = get_user_model()
        
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        return jsonify({
            'user': {
                'id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'isApproved': user['isApproved'],
                'isAdmin': user['isAdmin'],
                'createdAt': user['createdAt'].isoformat()
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to get profile', 'error': str(e)}), 500

@auth_bp.route('/secret-key', methods=['GET'])
@jwt_required()
def get_secret_key():
    try:
        user_id = get_jwt_identity()
        user_model = get_user_model()
        
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if not user['isApproved']:
            return jsonify({
                'message': 'Account pending approval',
                'isApproved': False
            }), 403
        
        # Decrypt the user's key
        decrypted_key = user_model.decrypt_user_key(user['encryptedKey'])
        
        return jsonify({
            'message': 'Secret key retrieved successfully',
            'secretKey': decrypted_key,
            'user': {
                'id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName']
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve secret key', 'error': str(e)}), 500

@auth_bp.route('/verify', methods=['POST'])
@jwt_required()
def verify_token():
    try:
        user_id = get_jwt_identity()
        user_model = get_user_model()
        
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        return jsonify({
            'message': 'Token is valid',
            'user': {
                'id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'isApproved': user['isApproved'],
                'isAdmin': user['isAdmin']
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Token verification failed', 'error': str(e)}), 500

