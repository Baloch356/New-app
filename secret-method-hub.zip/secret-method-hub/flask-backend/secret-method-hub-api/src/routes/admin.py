from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from src.models.user import UserModel
from bson import ObjectId

admin_bp = Blueprint('admin', __name__)

def get_user_model():
    """Get user model instance"""
    return UserModel(current_app.mongo)

def require_admin():
    """Decorator to require admin access"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            try:
                user_id = get_jwt_identity()
                claims = get_jwt()
                
                if not claims.get('isAdmin'):
                    return jsonify({'message': 'Admin access required'}), 403
                
                user_model = get_user_model()
                user = user_model.find_by_id(user_id)
                
                if not user or not user['isAdmin'] or not user['isApproved']:
                    return jsonify({'message': 'Admin access required'}), 403
                
                return f(*args, **kwargs)
            except Exception as e:
                return jsonify({'message': 'Authentication failed', 'error': str(e)}), 500
        
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@require_admin()
def get_users():
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))
        status = request.args.get('status', 'all')
        
        user_model = get_user_model()
        users, total = user_model.get_users_by_status(status, page, limit)
        
        # Convert ObjectId to string and format dates
        formatted_users = []
        for user in users:
            formatted_user = {
                '_id': str(user['_id']),
                'email': user['email'],
                'firstName': user['firstName'],
                'lastName': user['lastName'],
                'isApproved': user['isApproved'],
                'isAdmin': user['isAdmin'],
                'createdAt': user['createdAt'].isoformat(),
                'updatedAt': user['updatedAt'].isoformat(),
                'approvedAt': user['approvedAt'].isoformat() if user['approvedAt'] else None,
                'rejectedAt': user['rejectedAt'].isoformat() if user['rejectedAt'] else None,
                'rejectionReason': user.get('rejectionReason'),
                'approvedBy': str(user['approvedBy']) if user.get('approvedBy') else None,
                'rejectedBy': str(user['rejectedBy']) if user.get('rejectedBy') else None
            }
            formatted_users.append(formatted_user)
        
        return jsonify({
            'users': formatted_users,
            'pagination': {
                'currentPage': page,
                'totalPages': (total + limit - 1) // limit,
                'totalUsers': total,
                'hasNext': page * limit < total,
                'hasPrev': page > 1
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve users', 'error': str(e)}), 500

@admin_bp.route('/stats', methods=['GET'])
@jwt_required()
@require_admin()
def get_stats():
    try:
        user_model = get_user_model()
        stats = user_model.get_user_stats()
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve statistics', 'error': str(e)}), 500

@admin_bp.route('/approve/<user_id>', methods=['POST'])
@jwt_required()
@require_admin()
def approve_user(user_id):
    try:
        admin_id = get_jwt_identity()
        user_model = get_user_model()
        
        # Check if user exists
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user['isAdmin']:
            return jsonify({'message': 'Cannot modify admin user'}), 400
        
        if user['isApproved']:
            return jsonify({'message': 'User is already approved'}), 400
        
        # Approve user
        success = user_model.approve_user(user_id, admin_id)
        if not success:
            return jsonify({'message': 'Failed to approve user'}), 500
        
        # Get updated user
        updated_user = user_model.find_by_id(user_id)
        
        return jsonify({
            'message': 'User approved successfully',
            'user': {
                'id': str(updated_user['_id']),
                'email': updated_user['email'],
                'firstName': updated_user['firstName'],
                'lastName': updated_user['lastName'],
                'isApproved': updated_user['isApproved'],
                'approvedAt': updated_user['approvedAt'].isoformat() if updated_user['approvedAt'] else None
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to approve user', 'error': str(e)}), 500

@admin_bp.route('/reject/<user_id>', methods=['POST'])
@jwt_required()
@require_admin()
def reject_user(user_id):
    try:
        admin_id = get_jwt_identity()
        data = request.get_json() or {}
        reason = data.get('reason')
        
        user_model = get_user_model()
        
        # Check if user exists
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        if user['isAdmin']:
            return jsonify({'message': 'Cannot modify admin user'}), 400
        
        # Reject user
        success = user_model.reject_user(user_id, admin_id, reason)
        if not success:
            return jsonify({'message': 'Failed to reject user'}), 500
        
        # Get updated user
        updated_user = user_model.find_by_id(user_id)
        
        return jsonify({
            'message': 'User rejected successfully',
            'user': {
                'id': str(updated_user['_id']),
                'email': updated_user['email'],
                'firstName': updated_user['firstName'],
                'lastName': updated_user['lastName'],
                'isApproved': updated_user['isApproved'],
                'rejectedAt': updated_user['rejectedAt'].isoformat() if updated_user['rejectedAt'] else None,
                'rejectionReason': updated_user.get('rejectionReason')
            }
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to reject user', 'error': str(e)}), 500

@admin_bp.route('/user/<user_id>', methods=['GET'])
@jwt_required()
@require_admin()
def get_user_details(user_id):
    try:
        user_model = get_user_model()
        
        user = user_model.find_by_id(user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        formatted_user = {
            '_id': str(user['_id']),
            'email': user['email'],
            'firstName': user['firstName'],
            'lastName': user['lastName'],
            'isApproved': user['isApproved'],
            'isAdmin': user['isAdmin'],
            'createdAt': user['createdAt'].isoformat(),
            'updatedAt': user['updatedAt'].isoformat(),
            'approvedAt': user['approvedAt'].isoformat() if user['approvedAt'] else None,
            'rejectedAt': user['rejectedAt'].isoformat() if user['rejectedAt'] else None,
            'rejectionReason': user.get('rejectionReason'),
            'approvedBy': str(user['approvedBy']) if user.get('approvedBy') else None,
            'rejectedBy': str(user['rejectedBy']) if user.get('rejectedBy') else None
        }
        
        return jsonify({'user': formatted_user})
        
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve user details', 'error': str(e)}), 500

@admin_bp.route('/bulk-approve', methods=['POST'])
@jwt_required()
@require_admin()
def bulk_approve():
    try:
        admin_id = get_jwt_identity()
        data = request.get_json()
        
        user_ids = data.get('userIds', [])
        if not isinstance(user_ids, list) or len(user_ids) == 0:
            return jsonify({'message': 'User IDs array is required'}), 400
        
        user_model = get_user_model()
        approved_users = []
        
        for user_id in user_ids:
            try:
                user = user_model.find_by_id(user_id)
                if user and not user['isAdmin'] and not user['isApproved']:
                    success = user_model.approve_user(user_id, admin_id)
                    if success:
                        approved_users.append({
                            'id': str(user['_id']),
                            'email': user['email'],
                            'firstName': user['firstName'],
                            'lastName': user['lastName']
                        })
            except Exception:
                continue  # Skip invalid user IDs
        
        return jsonify({
            'message': f'{len(approved_users)} users approved successfully',
            'approvedUsers': approved_users
        })
        
    except Exception as e:
        return jsonify({'message': 'Failed to approve users', 'error': str(e)}), 500

