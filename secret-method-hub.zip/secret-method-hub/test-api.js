const axios = require('axios');

// Test configuration
const BASE_URL = 'http://localhost:5000/api';
const TEST_USER = {
  firstName: 'Test',
  lastName: 'User',
  email: 'test@example.com',
  password: 'testpassword123'
};

const ADMIN_CREDENTIALS = {
  email: 'admin@secretmethod.com',
  password: 'admin123'
};

let userToken = '';
let adminToken = '';
let testUserId = '';

// Helper function to make API calls
const apiCall = async (method, endpoint, data = null, token = null) => {
  try {
    const config = {
      method,
      url: `${BASE_URL}${endpoint}`,
      headers: {}
    };

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    if (data) {
      config.data = data;
      config.headers['Content-Type'] = 'application/json';
    }

    const response = await axios(config);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

// Test functions
const testServerHealth = async () => {
  console.log('\n🔍 Testing server health...');
  const result = await apiCall('GET', '/');
  if (result.success) {
    console.log('✅ Server is running');
    console.log('📋 Available endpoints:', result.data.endpoints);
  } else {
    console.log('❌ Server health check failed:', result.error);
  }
  return result.success;
};

const testUserRegistration = async () => {
  console.log('\n👤 Testing user registration...');
  const result = await apiCall('POST', '/auth/register', TEST_USER);
  if (result.success) {
    console.log('✅ User registration successful');
    userToken = result.data.token;
    testUserId = result.data.user.id;
    console.log('🔑 User token received');
    console.log('👤 User ID:', testUserId);
  } else {
    console.log('❌ User registration failed:', result.error);
  }
  return result.success;
};

const testAdminLogin = async () => {
  console.log('\n🔐 Testing admin login...');
  const result = await apiCall('POST', '/auth/login', ADMIN_CREDENTIALS);
  if (result.success) {
    console.log('✅ Admin login successful');
    adminToken = result.data.token;
    console.log('🔑 Admin token received');
  } else {
    console.log('❌ Admin login failed:', result.error);
  }
  return result.success;
};

const testUserProfile = async () => {
  console.log('\n📋 Testing user profile access...');
  const result = await apiCall('GET', '/auth/profile', null, userToken);
  if (result.success) {
    console.log('✅ User profile access successful');
    console.log('👤 User info:', result.data.user);
  } else {
    console.log('❌ User profile access failed:', result.error);
  }
  return result.success;
};

const testAdminStats = async () => {
  console.log('\n📊 Testing admin statistics...');
  const result = await apiCall('GET', '/admin/stats', null, adminToken);
  if (result.success) {
    console.log('✅ Admin stats access successful');
    console.log('📈 Stats:', result.data);
  } else {
    console.log('❌ Admin stats access failed:', result.error);
  }
  return result.success;
};

const testUserApproval = async () => {
  console.log('\n✅ Testing user approval...');
  const result = await apiCall('POST', `/admin/approve/${testUserId}`, null, adminToken);
  if (result.success) {
    console.log('✅ User approval successful');
    console.log('👤 Approved user:', result.data.user);
  } else {
    console.log('❌ User approval failed:', result.error);
  }
  return result.success;
};

const testSecretContent = async () => {
  console.log('\n🔒 Testing secret content access...');
  const result = await apiCall('GET', '/users/secret-content', null, userToken);
  if (result.success) {
    console.log('✅ Secret content access successful');
    console.log('🎯 Content available:', !!result.data.content);
  } else {
    console.log('❌ Secret content access failed:', result.error);
  }
  return result.success;
};

const testUnauthorizedAccess = async () => {
  console.log('\n🚫 Testing unauthorized access...');
  const result = await apiCall('GET', '/admin/stats');
  if (!result.success && result.error.includes('token')) {
    console.log('✅ Unauthorized access properly blocked');
    return true;
  } else {
    console.log('❌ Unauthorized access not properly blocked');
    return false;
  }
};

// Main test runner
const runTests = async () => {
  console.log('🚀 Starting API Tests for Secret Method Hub');
  console.log('=' .repeat(50));

  const tests = [
    { name: 'Server Health', fn: testServerHealth },
    { name: 'User Registration', fn: testUserRegistration },
    { name: 'Admin Login', fn: testAdminLogin },
    { name: 'User Profile', fn: testUserProfile },
    { name: 'Admin Stats', fn: testAdminStats },
    { name: 'User Approval', fn: testUserApproval },
    { name: 'Secret Content', fn: testSecretContent },
    { name: 'Unauthorized Access', fn: testUnauthorizedAccess }
  ];

  let passed = 0;
  let failed = 0;

  for (const test of tests) {
    try {
      const success = await test.fn();
      if (success) {
        passed++;
      } else {
        failed++;
      }
    } catch (error) {
      console.log(`❌ ${test.name} threw an error:`, error.message);
      failed++;
    }
  }

  console.log('\n' + '=' .repeat(50));
  console.log('📊 Test Results:');
  console.log(`✅ Passed: ${passed}`);
  console.log(`❌ Failed: ${failed}`);
  console.log(`📈 Success Rate: ${((passed / (passed + failed)) * 100).toFixed(1)}%`);

  if (failed === 0) {
    console.log('\n🎉 All tests passed! The API is working correctly.');
  } else {
    console.log('\n⚠️  Some tests failed. Please check the server and database connection.');
  }
};

// Run tests if this file is executed directly
if (require.main === module) {
  runTests().catch(console.error);
}

module.exports = { runTests };

