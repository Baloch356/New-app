# Secret Method Hub - Quick Deployment Guide

## 🚀 Quick Start for Replit

### 1. Upload to Replit
1. Create a new Repl on [Replit](https://replit.com)
2. Choose "Import from GitHub" or upload the project files
3. Ensure all files are in the correct structure

### 2. Set Environment Variables
In Replit, go to the "Secrets" tab (🔒) and add:

```
MONGODB_URI=mongodb+srv://username:password@cluster0.mongodb.net/secret-method-hub?retryWrites=true&w=majority
JWT_SECRET=your-super-secret-jwt-key-minimum-32-characters-long
ADMIN_EMAIL=admin@secretmethod.com
ADMIN_PASSWORD=admin123
ENCRYPTION_KEY=your-32-character-encryption-key-here
```

### 3. Run Deployment Script
In the Replit shell, run:
```bash
./deploy-replit.sh
```

### 4. Start the Application
Click the "Run" button in Replit.

## 🔐 Default Admin Access
- **Email**: admin@secretmethod.com
- **Password**: admin123
- **⚠️ Change these credentials in production!**

## 📱 User Flow Testing
1. **Register a new user** at `/register`
2. **Login as admin** at `/login` with admin credentials
3. **Approve the user** in the admin panel at `/admin`
4. **Login as the user** to see secret content

## 🛠️ MongoDB Atlas Setup
1. Create free account at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Create a new cluster (free tier)
3. Create database user with read/write permissions
4. Whitelist IP addresses (use 0.0.0.0/0 for development)
5. Get connection string and update `MONGODB_URI`

## 🔧 Troubleshooting
- **Can't connect to MongoDB**: Check connection string and IP whitelist
- **Admin not created**: Check MongoDB connection and environment variables
- **Frontend not loading**: Ensure build was successful and static files are served
- **API errors**: Check server logs in Replit console

## 📞 Support
Refer to the main README.md for detailed documentation and troubleshooting.

