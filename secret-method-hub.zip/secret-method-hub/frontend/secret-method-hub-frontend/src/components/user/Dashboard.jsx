import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { userAPI } from '../../services/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Clock, 
  CheckCircle, 
  XCircle, 
  ExternalLink, 
  Download, 
  Play,
  LogOut,
  User,
  Key
} from 'lucide-react';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const [secretContent, setSecretContent] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (user?.isApproved) {
      fetchSecretContent();
    }
  }, [user]);

  const fetchSecretContent = async () => {
    setIsLoading(true);
    try {
      const response = await userAPI.getSecretContent();
      setSecretContent(response.data.content);
    } catch (error) {
      setError('Failed to load secret content');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = () => {
    if (user?.isApproved) {
      return <Badge variant="default" className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
    } else if (user?.rejectedAt) {
      return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
    } else {
      return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Pending Approval</Badge>;
    }
  };

  const renderPendingApproval = () => (
    <div className="text-center py-12">
      <Clock className="w-16 h-16 mx-auto text-yellow-500 mb-4" />
      <h2 className="text-2xl font-bold mb-2">Waiting for Approval</h2>
      <p className="text-muted-foreground mb-6">
        Your account is currently under review. You'll receive access to secret content once approved by an administrator.
      </p>
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 max-w-md mx-auto">
        <p className="text-sm text-yellow-800">
          <strong>What happens next?</strong><br />
          Our team will review your application and notify you via email once a decision is made.
        </p>
      </div>
    </div>
  );

  const renderRejected = () => (
    <div className="text-center py-12">
      <XCircle className="w-16 h-16 mx-auto text-red-500 mb-4" />
      <h2 className="text-2xl font-bold mb-2">Application Rejected</h2>
      <p className="text-muted-foreground mb-6">
        Unfortunately, your application has been rejected.
      </p>
      {user?.rejectionReason && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 max-w-md mx-auto mb-6">
          <p className="text-sm text-red-800">
            <strong>Reason:</strong> {user.rejectionReason}
          </p>
        </div>
      )}
      <p className="text-sm text-muted-foreground">
        If you believe this was an error, please contact support.
      </p>
    </div>
  );

  const renderApprovedContent = () => (
    <div className="space-y-6">
      <div className="text-center py-8">
        <CheckCircle className="w-16 h-16 mx-auto text-green-500 mb-4" />
        <h2 className="text-3xl font-bold mb-2">You Are Approved!</h2>
        <p className="text-muted-foreground">
          Congratulations! You now have access to exclusive secret content.
        </p>
      </div>

      {isLoading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading secret content...</p>
        </div>
      ) : error ? (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : secretContent ? (
        <div className="space-y-6">
          {/* Secret Links */}
          {secretContent.links && secretContent.links.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ExternalLink className="w-5 h-5 mr-2" />
                  Secret Methods & Resources
                </CardTitle>
                <CardDescription>
                  Exclusive links to advanced techniques and strategies
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {secretContent.links.map((link, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">{link.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{link.description}</p>
                    <Button asChild size="sm">
                      <a href={link.url} target="_blank" rel="noopener noreferrer">
                        Access Resource <ExternalLink className="w-3 h-3 ml-1" />
                      </a>
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Secret Videos */}
          {secretContent.videos && secretContent.videos.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Play className="w-5 h-5 mr-2" />
                  Exclusive Video Content
                </CardTitle>
                <CardDescription>
                  Master classes and training sessions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {secretContent.videos.map((video, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">{video.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{video.description}</p>
                    <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                      <iframe
                        src={video.embedUrl}
                        title={video.title}
                        className="w-full h-full rounded-lg"
                        frameBorder="0"
                        allowFullScreen
                      ></iframe>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Secret Documents */}
          {secretContent.documents && secretContent.documents.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Download className="w-5 h-5 mr-2" />
                  Downloadable Resources
                </CardTitle>
                <CardDescription>
                  Handbooks, guides, and documentation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {secretContent.documents.map((doc, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <h4 className="font-semibold mb-2">{doc.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{doc.description}</p>
                    <Button asChild size="sm" variant="outline">
                      <a href={doc.downloadUrl} target="_blank" rel="noopener noreferrer">
                        Download <Download className="w-3 h-3 ml-1" />
                      </a>
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      ) : null}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold">Secret Method Hub</h1>
              {getStatusBadge()}
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span className="text-sm font-medium">
                  {user?.firstName} {user?.lastName}
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={logout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* User Info Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="w-5 h-5 mr-2" />
              Account Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Name</p>
                <p className="text-sm">{user?.firstName} {user?.lastName}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Email</p>
                <p className="text-sm">{user?.email}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Status</p>
                <div className="mt-1">{getStatusBadge()}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content based on approval status */}
        {user?.isApproved ? renderApprovedContent() : 
         user?.rejectedAt ? renderRejected() : 
         renderPendingApproval()}
      </main>
    </div>
  );
};

export default Dashboard;

